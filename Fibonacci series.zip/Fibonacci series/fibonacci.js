let number = parseInt(prompt('Enter the positve number'));
let c1 = 0;
let c2 = 1;
let t;

for(let i=1; i<=number;i++){
    console.log(c1);
    t = c1+c2;
    c1 = c2;
    c2 = t;
}